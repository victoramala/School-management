require "test_helper"

class CouseTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
