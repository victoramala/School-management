Rails.application.routes.draw do
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Defines the root path route ("/")
  root "home#index"

  # Authentication
  get '/home/login'
  post '/sign_in', to: 'session#sign_in'
  delete '/logout', to: 'session#logout'


  get '/dashboard', to: 'dashboard#index'

  # API routes
  namespace :api do
    namespace :v1 do
      resources :users, only: [:create]
      resources :schools do
        resources :courses, controller: 'schools/courses'
      end
      resources :batches do
        resources :enrollments, controller: 'batches/enrollments'
      end
      resources :enrollments, only: [:create, :show] do
        member do
          put :approve
          put :deny
        end
      end
    end
  end
  
end
