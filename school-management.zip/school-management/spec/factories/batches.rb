FactoryBot.define do
  factory :batch do
    name { Faker::Educator.course_name }
    start_date { Faker::Date.between(from: 1.month.ago, to: Date.today) }
    end_date { Faker::Date.between(from: Date.today, to: 6.months.from_now) }
    course
  end
end