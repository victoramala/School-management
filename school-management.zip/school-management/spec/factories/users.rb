FactoryBot.define do
  factory :user do
    first_name { Faker::Name.first_name }
    last_name { Faker::Name.last_name }
    email { Faker::Internet.email }
    password { Faker::Internet.password  }

    trait :admin do
      after(:create) do |user|
        role = Role.where(name: "Admin").first_or_create
        UserRole.create(user: user, role: role)
      end
    end

    trait :school_admin do
      after(:create) do |user|
        role = Role.where(name: "SchoolAdmin").first_or_create
        UserRole.create(user: user, role: role)
      end
    end

    trait :student do
      after(:create) do |user|
        role = Role.where(name: "Student").first_or_create
        UserRole.create(user: user, role: role)
      end
    end
  end
end
