FactoryBot.define do
  factory :school do
    name { Faker::University.name }
    description { Faker::Lorem.paragraph }
    address { Faker::Address.full_address }
    phone { Faker::PhoneNumber.phone_number }
  end
end