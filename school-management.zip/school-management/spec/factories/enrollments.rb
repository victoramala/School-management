FactoryBot.define do
  factory :enrollment do
    status { "pending" }
    batch

    trait :student do
      association :student, factory: :user, strategy: :create
    end

    trait :approved do
      status { "approved" }
    end

    trait :denied do
      status { "denied" }
    end
  end
end
  