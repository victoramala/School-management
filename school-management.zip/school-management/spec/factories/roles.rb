FactoryBot.define do
  factory :role do
    trait :school_admin do
      name { "Admin" }
    end

    trait :school_admin do
      name { "SchoolAdmin" }
    end

    trait :student do
      name { "Student" }
    end
  end
end
  