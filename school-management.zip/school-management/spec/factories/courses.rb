FactoryBot.define do
  factory :course do
    name { Faker::Educator.course_name }
    description { Faker::Lorem.paragraph }
    start_date { Faker::Date.between(from: 1.month.ago, to: Date.today) }
    end_date { Faker::Date.between(from: Date.today, to: 6.months.from_now) }
    school

  end
end