require 'rails_helper'
require 'pundit/rspec'

RSpec.describe EnrollmentPolicy do
    subject { described_class }
  
    let(:admin) { create(:user, :admin) }
    let(:school_admin) { create(:user, :school_admin) }
    let(:student) { create(:user, :student) }
    let(:enrollment_pending) { Enrollment.new(status: 'pending') }
    let(:enrollment_approved) { Enrollment.new(status: 'approved') }
  
    permissions :index? do
      it "allows access for admin" do
        expect(subject).to permit(admin)
      end
  
      it "allows access for school admin" do
        expect(subject).to permit(school_admin)
      end
  
      it "allows access for student" do
        expect(subject).to permit(student)
      end
    end
  
    permissions :show? do
      it "allows show for admin" do
        expect(subject).to permit(admin)
      end
  
      it "allows show for school admin" do
        expect(subject).to permit(school_admin)
      end
  
      it "allows show for student" do
        expect(subject).to permit(student)
      end
    end
  
    permissions :create? do
      it "allows creation for admin" do
        expect(subject).to permit(admin)
      end
  
      it "allows creation for school admin" do
        expect(subject).to permit(school_admin)
      end
  
      it "allows creation for student with pending status" do
        expect(subject).to permit(student, enrollment_pending)
      end
  
      it "denies creation for student with approved status" do
        expect(subject).not_to permit(student, enrollment_approved)
      end
    end
  
    permissions :approve? do
      it "allows approval for admin" do
        expect(subject).to permit(admin)
      end
  
      it "allows approval for school admin" do
        expect(subject).to permit(school_admin)
      end
  
      it "denies approval for student" do
        expect(subject).not_to permit(student)
      end
    end
  
    permissions :deny? do
      it "allows denial for admin" do
        expect(subject).to permit(admin)
      end
  
      it "allows denial for school admin" do
        expect(subject).to permit(school_admin)
      end
  
      it "denies denial for student" do
        expect(subject).not_to permit(student)
      end
    end
  end
  