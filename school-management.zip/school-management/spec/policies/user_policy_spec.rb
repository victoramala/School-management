require 'rails_helper'
require 'pundit/rspec'

RSpec.describe UserPolicy, type: :policy do
  subject { described_class }

  let(:admin) { create(:user, :admin) }
  let(:school_admin) { create(:user, :school_admin) }
  let(:student) { create(:user, :student) }

  permissions :create? do
    it "allows creation for admin" do
      expect(subject).to permit(admin)
    end

    it "denies creation for school admin" do
      expect(subject).not_to permit(school_admin)
    end

    it "denies creation for student" do
      expect(subject).not_to permit(student)
    end
  end
end
