require 'rails_helper'
require 'pundit/rspec'

RSpec.describe CoursePolicy do
  subject { described_class }

  let(:admin) { create(:user, :admin) }
  let(:school_admin) { create(:user, :school_admin) }
  let(:student) { create(:user, :student) }

  permissions :create? do
    it "allows creation for admin" do
      expect(subject).to permit(admin)
    end

    it "allows creation for school admin" do
      expect(subject).to permit(school_admin)
    end

    it "denies creation for student" do
      expect(subject).not_to permit(student)
    end
  end

  permissions :update? do
    it "allows update for admin" do
      expect(subject).to permit(admin)
    end

    it "allows update for school admin" do
      expect(subject).to permit(school_admin)
    end

    it "denies update for student" do
      expect(subject).not_to permit(student)
    end
  end

  permissions :index? do
    it "allows access for admin" do
      expect(subject).to permit(admin)
    end

    it "allows access for school admin" do
      expect(subject).to permit(school_admin)
    end

    it "denies access for student" do
      expect(subject).not_to permit(student)
    end
  end

  permissions :show? do
    it "allows show for admin" do
      expect(subject).to permit(admin)
    end

    it "allows show for school admin" do
      expect(subject).to permit(school_admin)
    end

    it "denies show for student" do
      expect(subject).not_to permit(student)
    end
  end
end
  