require 'rails_helper'

RSpec.describe 'Api::V1::UsersController', type: :request do
  describe 'POST /api/v1/users' do
    let!(:admin_role) { create_role('Admin') }
    let!(:school_admin_role) { create_role('SchoolAdmin') }
    let!(:student_role) { create_role('Student') }

    context 'when admin is authenticated' do
      let(:admin) { create(:user, :admin) }
      let(:admin_headers) { sign_in(admin) }

      context 'with valid params' do
        let(:params) do
          {
            user: {
              first_name: 'John',
              last_name: 'Doe',
              email: 'john@example.com',
              password: 'password',
              password_confirmation: 'password',
              role: 'SchoolAdmin'
            }
          }
        end

        it 'creates a new user' do
          expect {
            post '/api/v1/users', params: params, headers: admin_headers, as: :json
          }.to change(User, :count).by(2) # Here we are checking 2 because already we have Admin User
          
          expect(response).to have_http_status(:created)
          expect(response.body).to include('auth_token')
        end
      end

      context 'with invalid params' do
        let(:params) do
          {
            user: {
              first_name: 'John',
              last_name: 'Doe',
              email: '',
              password: 'password',
              password_confirmation: 'passwor',
              role: 'InvalidRole'
            }
          }
        end

        it 'returns unprocessable_entity status' do
          post '/api/v1/users', params: params, headers: admin_headers, as: :json
          expect(response).to have_http_status(:unprocessable_entity)
        end

        it 'returns an error message' do
          post '/api/v1/users', params: params, headers: admin_headers, as: :json

          expect(JSON.parse(response.body)['errors']).to include(
            "Email can't be blank, Email is invalid",
            "Password confirmation doesn't match Password"
          )
        end
      end

      context 'with invalid role' do
        let(:params) do
          {
            user: {
              first_name: 'John',
              last_name: 'Doe',
              email: 'Doe@email.com',
              password: 'password',
              password_confirmation: 'password',
              role: 'InvalidRole'
            }
          }
        end
  
        it 'returns an error message' do
          post '/api/v1/users', params: params, headers: admin_headers, as: :json

          expect(JSON.parse(response.body)['errors']).to include(
            "Unsupported Role: Must be one of Admin, SchoolAdmin, Student"
          )
        end
      end
    end

    context 'when school_admin is authenticated' do
      let(:school_admin) { create(:user, :school_admin) }
      let(:school_admin_headers) { sign_in(school_admin) }

      let(:params) do
        {
          user: {
            first_name: 'Rick',
            last_name: 'Morre',
            email: 'Rick@example.com',
            password: 'password',
            password_confirmation: 'password',
            role: 'Student'
          }
        }
      end

      it 'returns forbidden status' do
        post '/api/v1/users', params: params, headers: school_admin_headers, as: :json
        expect(response).to have_http_status(:unprocessable_entity)
      end
    end

    context 'when student is authenticated' do
      let(:student) { create(:user, :student) }
      let(:student_headers) { sign_in(student) }

      let(:params) do
        {
          user: {
            first_name: 'John',
            last_name: 'Doe',
            email: 'john@example.com',
            password: 'password',
            password_confirmation: 'password',
            role: 'Student'
          }
        }
      end

      it 'returns forbidden status' do
        post '/api/v1/users', params: params, headers: student_headers, as: :json
        expect(response).to have_http_status(:unprocessable_entity)
      end
    end
  end
end
