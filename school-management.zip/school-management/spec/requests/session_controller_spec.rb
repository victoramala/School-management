require 'rails_helper'

RSpec.describe 'Session API', type: :request do
  let!(:admin) { create(:user, role: 'admin') }
  let!(:school_admin) { create(:user, role: 'school_admin') }
  let!(:student) { create(:user, role: 'student') }

  describe 'POST /sign_in' do
    context 'when signing in as an admin' do
      before do
        post '/sign_in', params: { user: { email: admin.email, password: admin.password } }, as: :json
      end
      

      it 'returns a valid authentication token' do
        expect(response).to have_http_status(:created)
        expect(response.body).to include('auth_token')
      end
    end

    context 'when signing in as a school admin' do
      before do
        post '/sign_in', params: { user: { email: school_admin.email, password: school_admin.password } },  as: :json
      end

      it 'returns a valid authentication token' do
        expect(response).to have_http_status(:created)
        expect(response.body).to include('auth_token')
      end
    end

    context 'when signing in as a student' do
      before do
        post '/sign_in', params: { user: { email: student.email, password: student.password} },  as: :json
      end

      it 'returns a valid authentication token' do
        expect(response).to have_http_status(:created)
        expect(response.body).to include('auth_token')
      end
    end

    context 'when submitting blank credentials' do
      before do
        post '/sign_in', params: { user: { email: '', password: '' } },  as: :json
      end

      it 'returns an unauthorized error' do
        expect(response).to have_http_status(:unauthorized)
        expect(response.body).to include('Invalid email or password')
      end
    end

    context 'when submitting invalid credentials' do
      before do
        post '/sign_in', params: { user: { email: 'invalid@example.com', password: 'password' } },  as: :json
      end

      it 'returns an unauthorized error' do
        expect(response).to have_http_status(:unauthorized)
        expect(response.body).to include('Invalid email or password')
      end
    end
  end

  describe 'DELETE /logout' do
    context 'when user is authenticated' do
      let(:user) { create(:user) }

      before do
        post '/sign_in', params: { user: { email: user.email, password: user.password } }, as: :json
        @token = JSON.parse(response.body)['auth_token']
      end

      it 'logs the user out' do
        delete '/logout', headers: {'Authorization': "Bearer #{@token}" }
        expect(response).to redirect_to(root_path)
        expect(session[:user_id]).to be_nil
      end
    end
  end
end
