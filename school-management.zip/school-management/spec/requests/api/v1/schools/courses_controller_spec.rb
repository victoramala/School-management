require 'rails_helper'

RSpec.describe Api::V1::Schools::CoursesController, type: :request do
  let(:school_admin) { create(:user, :school_admin) }
  let(:admin) { create(:user, :admin) }
  let(:student) { create(:user, :student) }
  let(:school) { create(:school) }

  describe "POST /api/v1/schools/:school_id/courses" do
    let(:course_a_params) do
      {
        course: {
          name: "Biology",
          description: "A course about the study of life",
          start_date: Date.today,
          end_date: Date.today + 1.month,
          course_type: "Part time"
        }
      }
    end

    let(:course_b_params) do
      {
        course: {
          name: "Maths",
          description: "A course about the study of life",
          start_date: Date.today,
          end_date: Date.today + 1.month,
          course_type: "Full time",
          batches_attributes: [
            {
              name: "Batch A",
              start_date: Date.today,
              end_date: Date.today + 3.months,
              description: "A batch for biology course"
            }
          ]
        }
      }
    end
  
    context "when user is an admin" do
      let(:headers) { sign_in(admin) }
  
      it "creates a new course" do
        expect {
          post "/api/v1/schools/#{school.id}/courses", headers: headers, params: course_a_params, as: :json
        }.to change(Course, :count).by(1)
        
        expect(response).to have_http_status(:created)
        expect(response.body).to include("Biology")
        expect(Batch.count).to eq(0)
      end
  
      it "creates a new course with batches" do
        expect {
          post "/api/v1/schools/#{school.id}/courses?includes=batches", headers: headers, params: course_b_params, as: :json
        }.to change(Batch, :count).by(1)
  
        expect(response).to have_http_status(:created)
      end
    end
  
    context "when user is a school admin" do
      let(:headers) { sign_in(school_admin) }
  
      it "creates a new course" do
        expect {
          post "/api/v1/schools/#{school.id}/courses", headers: headers, params: course_a_params, as: :json
        }.to change(Course, :count).by(1)
  
        expect(response).to have_http_status(:created)
        expect(response.body).to include("Biology")
      end
  
      it "creates a new course with batches" do
        expect {
          post "/api/v1/schools/#{school.id}/courses", headers: headers, params: course_b_params, as: :json
        }.to change(Batch, :count).by(1)
  
        expect(response).to have_http_status(:created)
      end
    end
  
    context "when user is not an admin or school admin" do
      let(:student_user) { create(:user, :student) }
      let(:headers) { sign_in(student_user) }
  
      it "returns a 'not authorized' error" do
        expect {
          post "/api/v1/schools/#{school.id}/courses", headers: headers, params: course_a_params, as: :json
        }.to_not change(Course, :count)
  
        expect(response).to have_http_status(:forbidden)
        expect(response.body).to include("You are not authorized to perform this action.")
      end
    end
  end

  describe "PATCH /api/v1/schools/:school_id/courses/:id" do
    let!(:course) { create(:course, school: school) }
  
    let(:valid_params) do
      {
        course: {
          name: "New Biology Course Name",
          description: 'New Description',
          batches_attributes: [
            {
              name: "Batch B",
              start_date: Date.today,
              end_date: Date.today + 3.months,
              description: "A batch for biology course"
            }
          ]
        }
      }
    end
  
    context "when user is an admin" do
      let(:headers) { sign_in(admin) }
  
      it "updates the course and its batches" do
        patch "/api/v1/schools/#{school.id}/courses/#{course.id}", headers: headers, params: valid_params, as: :json
        course.reload
  
        expect(response).to have_http_status(:ok)
        expect(JSON.parse(response.body)['data']['attributes']['name']).to include("New Biology")
        expect(JSON.parse(response.body)['data']['attributes']['description']).to include("New Description")
        expect(course.batches.count).to eq(1)
        expect(course.batches.first.name).to eq("Batch B")
      end
    end
  
    context "when user is an school admin" do
      let(:course) { create(:course, name: 'Old Name', description: 'Old Description', school: school) }
      let(:headers) { sign_in(school_admin) }
  
      it "updates the course and its batches" do
        patch "/api/v1/schools/#{school.id}/courses/#{course.id}", headers: headers, params: valid_params, as: :json
        course.reload
  
        expect(response).to have_http_status(:ok)
        expect(JSON.parse(response.body)['data']['attributes']['name']).to include("New Biology")
        expect(JSON.parse(response.body)['data']['attributes']['description']).to include("New Description")
        expect(course.batches.count).to eq(1)
        expect(course.batches.first.name).to eq("Batch B")
      end
    end
  
    context "when student is not authorized" do
      let(:course) { create(:course, name: 'Old Name', description: 'Old Description', school: school) }
  
      it "returns unauthorized status code" do
        patch "/api/v1/schools/#{school.id}/courses/#{course.id}", headers: sign_in(student), params: valid_params, as: :json
  
        expect(response).to have_http_status(:forbidden)
        expect(response.body).to include("You are not authorized to perform this action.")
      end
    end
  end
  

  describe 'GET /api/v1/schools/:school_id/courses' do
    let!(:courses) { create_list(:course, 3, school: school) }
    let(:course) { courses.first }

    context 'when user is authenticated and authorized' do
      it 'returns a list of courses' do
        get "/api/v1/schools/#{school.id}/courses", headers: sign_in(admin), as: :json

        expect(response).to have_http_status(:ok)
        expect(JSON.parse(response.body)['data'].count).to eq(3)
      end
    end

    context 'when user is not authenticated' do
      it 'returns unauthorized error' do
        get "/api/v1/schools/#{school.id}/courses", as: :json

        expect(response).to have_http_status(:unauthorized)
        expect(JSON.parse(response.body)['error']).to eq('Token is invalid')
      end
    end

    context 'when user is authenticated but not authorized' do
      it 'returns forbidden error' do
        get "/api/v1/schools/#{school.id}/courses", headers: sign_in(student), as: :json
        
        expect(response).to have_http_status(:forbidden)
        expect(JSON.parse(response.body)['error']).to eq('You are not authorized to perform this action.')
      end
    end
  end

  describe 'GET /api/v1/schools/:school_id}/courses/:course_id' do
    let!(:courses) { create_list(:course, 3, school: school) }
    let(:course) { courses.first }

    context 'when user is authenticated and authorized' do
      it 'returns course details' do
        get "/api/v1/schools/#{school.id}/courses/#{course.id}", headers: sign_in(admin), as: :json

        expect(response).to have_http_status(:ok)
        expect(JSON.parse(response.body)['data']['attributes']['name']).to eq(course.name)
      end
    end

    context 'when user is not authenticated' do
      it 'returns unauthorized error' do
        get "/api/v1/schools/#{school.id}/courses/#{course.id}", as: :json

        expect(response).to have_http_status(:unauthorized)
        expect(JSON.parse(response.body)['error']).to eq('Token is invalid')
      end
    end

    context 'when user is authenticated but not authorized' do
      it 'returns forbidden error' do
        get "/api/v1/schools/#{school.id}/courses/#{course.id}", headers: sign_in(student), as: :json

        expect(response).to have_http_status(:forbidden)
        expect(JSON.parse(response.body)['error']).to eq('You are not authorized to perform this action.')
      end
    end
  end

  describe "DELETE /api/v1/schools/:school_id/courses/:id" do
    let!(:course) { create(:course, school: school) }
    let!(:batch) { create(:batch, course: course) }
  
    context "when user is an admin" do
      let(:headers) { sign_in(admin) }
  
      it "destroys the course and its batches" do
        expect {
          delete "/api/v1/schools/#{school.id}/courses/#{course.id}", headers: headers, as: :json
        }.to change(Course, :count).by(-1)
  
        expect(response).to have_http_status(:ok)
        expect(JSON.parse(response.body)["message"]).to eq('Course has been successfully deleted.')
        expect { course.reload }.to raise_error ActiveRecord::RecordNotFound
        expect { batch.reload }.to raise_error ActiveRecord::RecordNotFound
      end
    end
  
    context "when user is a school admin" do
      let(:headers) { sign_in(school_admin) }
  
      it "destroys the course and its batches" do
        expect {
          delete "/api/v1/schools/#{school.id}/courses/#{course.id}", headers: headers, as: :json
        }.to change(Course, :count).by(-1)
  
        expect(response).to have_http_status(:ok)
        expect(JSON.parse(response.body)["message"]).to eq('Course has been successfully deleted.')
        expect { course.reload }.to raise_error ActiveRecord::RecordNotFound
        expect { batch.reload }.to raise_error ActiveRecord::RecordNotFound
      end
    end
  
    context "when user is not an admin or school admin" do
      let(:headers) { sign_in(student) }
  
      it "returns unauthorized status code" do
        expect {
          delete "/api/v1/schools/#{school.id}/courses/#{course.id}", headers: headers, as: :json
        }.to_not change(Course, :count)
  
        expect(response).to have_http_status(:forbidden)
        expect(response.body).to include("You are not authorized to perform this action.")
      end
    end
  end
  
end
