require 'rails_helper'

RSpec.describe Api::V1::SchoolsController, type: :request do

  let(:admin) { create(:user, :admin }
  let(:school_admin) { create(:user, :school_admin) }
  let(:student) { create(:user, :student) }

  describe 'GET /api/v1/schools' do
    context 'when admin is authenticated' do
      let(:headers) { sign_in(admin) }
  
      it 'returns a list of schools' do
        create_list(:school, 3)
  
        get '/api/v1/schools', headers: headers, as: :json
  
        expect(response).to have_http_status(:ok)
        parsed_response = JSON.parse(response.body)
        expect(parsed_response['data'].size).to eq(3)
      end
    end
  
    context 'when school_admin is authenticated' do
      let(:headers) { sign_in(school_admin) }
  
      it 'returns a list of schools' do
        create_list(:school, 3)
  
        get '/api/v1/schools', headers: headers, as: :json
  
        expect(response).to have_http_status(:ok)
        parsed_response = JSON.parse(response.body)
        expect(parsed_response['data'].size).to eq(3)
      end
    end
  
    context 'when student is authenticated' do
      let(:headers) { sign_in(student) }
  
      it 'returns unauthorized' do
        get '/api/v1/schools', headers: headers, as: :json
        expect(response).to have_http_status(:forbidden)
      end
    end
  end
  
  describe 'GET /api/v1/schools/:id' do
    let(:school) { create(:school) }
  
    context 'when admin is authenticated' do
      let(:headers) { sign_in(admin) }
  
      it 'returns school details' do
        get "/api/v1/schools/#{school.id}", headers: headers, as: :json
  
        expect(response).to have_http_status(:ok)
        parsed_response = JSON.parse(response.body)
        expect(parsed_response['data']['id']).to eq(school.id.to_s)
      end
    end
  
    context 'when school_admin is authenticated' do
      let(:headers) { sign_in(school_admin) }
  
      it 'returns school details' do
        get "/api/v1/schools/#{school.id}", headers: headers, as: :json
  
        expect(response).to have_http_status(:ok)
        parsed_response = JSON.parse(response.body)
        expect(parsed_response['data']['id']).to eq(school.id.to_s)
      end
    end
  
    context 'when student is authenticated' do
      let(:headers) { sign_in(student) }
  
      it 'returns unauthorized' do
        get "/api/v1/schools/#{school.id}", headers: headers, as: :json
        expect(response).to have_http_status(:forbidden)
      end
    end
  end
  
  describe 'DELETE /api/v1/schools/:id' do
    let!(:school) { create(:school) }
  
    context 'when admin is authenticated' do
      let(:headers) { sign_in(admin) }
  
      it 'deletes the school' do
        expect {
          delete "/api/v1/schools/#{school.id}", headers: headers, as: :json
        }.to change(School, :count).by(-1)
  
        expect(response).to have_http_status(:ok)
        parsed_response = JSON.parse(response.body)
        expect(parsed_response["message"]).to eq('School has been successfully deleted.')
      end
    end
  
    context 'when school_admin is authenticated' do
      let(:headers) { sign_in(school_admin) }
  
      it 'returns unauthorized' do
        delete "/api/v1/schools/#{school.id}", headers: headers, as: :json
        expect(response).to have_http_status(:forbidden)
      end
    end
  
    context 'when student is authenticated' do
      let(:headers) { sign_in(student) }
  
      it 'returns unauthorized' do
        delete "/api/v1/schools/#{school.id}", headers: headers, as: :json
        expect(response).to have_http_status(:forbidden)
      end
    end
  end

  describe 'POST /api/v1/schools' do
    context 'when admin is authenticated' do
      let(:headers) { sign_in(admin) }

      it 'creates a new school' do
        expect {
          post '/api/v1/schools', params: { school: { name: 'New School', description: 'A new school' } }, headers: headers,  as: :json
        }.to change(School, :count).by(1)

        expect(response).to have_http_status(:created)
      end
    end

    context 'when school_admin is authenticated' do
      let(:headers) { sign_in(school_admin) }

      it 'returns unauthorized' do
        post '/api/v1/schools', params: { school: { name: 'New School', description: 'A new school' } }, headers: headers,  as: :json
        expect(response).to have_http_status(:forbidden)
      end
    end

    context 'when student is authenticated' do
      let(:headers) { sign_in(student) }

      it 'returns unauthorized' do
        post '/api/v1/schools', params: { school: { name: 'New School', description: 'A new school' } }, headers: headers,  as: :json
        expect(response).to have_http_status(:forbidden)
      end
    end
  end
  
  describe 'PATCH /api/v1/schools/:id' do
    let!(:school) { create(:school) }

    context 'when admin is authenticated' do
      let(:headers) { sign_in(admin) }

      it 'updates school details' do
        patch "/api/v1/schools/#{school.id}", params: { school: { name: 'Updated School by admin' } }, headers: headers, as: :json
        expect(response).to have_http_status(:ok)
        parsed_response = JSON.parse(response.body)
        expect(parsed_response['data']['attributes']['name']).to eq('Updated School by admin')
      end
    end
  
    context 'when school_admin is authenticated' do
      let(:headers) { sign_in(school_admin) }

      it 'updates school details' do
        patch "/api/v1/schools/#{school.id}", params: { school: { name: 'Updated School by school admin' } }, headers: headers, as: :json
        expect(response).to have_http_status(:ok)
        parsed_response = JSON.parse(response.body)
        expect(parsed_response['data']['attributes']['name']).to eq('Updated School by school admin')
      end
    end
  
    context 'when student is authenticated' do
      let(:headers) { sign_in(student) }
  
      it 'returns unauthorized' do
        patch "/api/v1/schools/#{school.id}", params: { school: { name: 'Updated School' } }, headers: headers, as: :json
        expect(response).to have_http_status(:forbidden)
      end
    end
  end
  
end
