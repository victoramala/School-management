require 'rails_helper'

RSpec.describe Api::V1::Batches::EnrollmentsController, type: :request do
  describe 'GET /api/v1/batches/:batch_id/enrollments' do
    let(:batch1) { create(:batch) }
    let(:batch2) { create(:batch) }
    let(:student1) { create(:user, :student) }
    let(:student2) { create(:user, :student) }
    let(:student3) { create(:user, :student) }
    let(:headers) { sign_in(student1) }

    it 'returns the student\'s enrollments for the same batch' do
      create(:enrollment, batch: batch1, student: student1, status: 'approved')
      create(:enrollment, batch: batch1, student: student2, status: 'approved')
      create(:enrollment, batch: batch1, student: student3, status: 'pending')

      get "/api/v1/batches/#{batch1.id}/enrollments", headers: headers, as: :json

      expect(response).to have_http_status(:ok)
      expect(JSON.parse(response.body)['data'].size).to eq(3)
      expect(JSON.parse(response.body)['data'][0]['attributes']['status']).to eq('approved')
    end

    it 'returns an empty response if the student has no enrollments in the batch' do
      create(:enrollment, batch: batch1, student: student2, status: 'approved')
      create(:enrollment, batch: batch1, student: student3, status: 'pending')

      get "/api/v1/batches/#{batch2.id}/enrollments", headers: headers, as: :json

      expect(response).to have_http_status(:ok)
      expect(JSON.parse(response.body)['data']).to be_empty
    end

    it 'returns a not authorized error if the student is not authenticated' do
      get "/api/v1/batches/#{batch2.id}/enrollments", as: :json

      expect(response).to have_http_status(:unauthorized)
      expect(JSON.parse(response.body)['error']).to eq('Token is invalid')
    end
  end
end
