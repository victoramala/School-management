require 'rails_helper'

RSpec.describe Api::V1::EnrollmentsController, type: :request do

  describe "POST /api/v1/enrollments" do
    let(:batch) { create(:batch) }
    let(:admin) { create(:user, :admin) }
    let(:school_admin) { create(:user, :school_admin) }
    let(:student1) { create(:user, :student) }
    let(:student2) { create(:user, :student) }
    let(:student3) { create(:user, :student) }
    let(:student4) { create(:user, :student) }

    context "when user is admin" do
      let(:headers) { sign_in(admin) }

      it "creates a new enrollment" do
        valid_params = {
          enrollment: {
            batch_id: batch.id,
            student_id: student1.id,
            status: "approved"
          }
        }

        expect {
          post "/api/v1/enrollments", headers: headers, params: valid_params, as: :json
        }.to change(Enrollment, :count).by(1)

        expect(response).to have_http_status(:created)
        expect(JSON.parse(response.body)['data']['attributes']['batch']).to eq(batch.name)
        expect(JSON.parse(response.body)['data']['attributes']['student']).to eq(student1.first_name)
        expect(JSON.parse(response.body)['data']['attributes']['status']).to eq("approved")
      end

      it "does not allow duplicate enrollments for the same batch and student" do
        existing_enrollment = create(:enrollment, batch: batch, student: student1)

        valid_params = {
          enrollment: {
            batch_id: batch.id,
            student_id: student1.id,
            status: "approved"
          }
        }

        expect {
          post "/api/v1/enrollments", headers: headers, params: valid_params, as: :json
        }.not_to change(Enrollment, :count)

        expect(response).to have_http_status(:unprocessable_entity)
        expect(response.body).to include("Student already enrolled in this batch")
      end
    end

    context "when user is school admin" do
      let(:headers) { sign_in(school_admin) }

      it "creates a new enrollment" do
        valid_params = {
          enrollment: {
            batch_id: batch.id,
            student_id: student2.id,
            status: "approved"
          }
        }

        expect {
          post "/api/v1/enrollments", headers: headers, params: valid_params, as: :json
        }.to change(Enrollment, :count).by(1)

        expect(response).to have_http_status(:created)
        expect(JSON.parse(response.body)['data']['attributes']['batch']).to eq(batch.name)
        expect(JSON.parse(response.body)['data']['attributes']['student']).to eq(student2.first_name)
        expect(JSON.parse(response.body)['data']['attributes']['status']).to eq("approved")
      end
    end

    context "when user is student" do
      let(:headers_3) { sign_in(student3) }
      let(:headers_4) { sign_in(student4) }

      it "creates a new enrollment" do
        valid_params = {
          enrollment: {
            batch_id: batch.id,
            student_id: student3.id,
            status: "pending"
          }
        }

        post "/api/v1/enrollments", headers: headers_3, params: valid_params, as: :json

        expect(response).to have_http_status(:created)
        expect(JSON.parse(response.body)['data']['attributes']['batch']).to eq(batch.name)
        expect(JSON.parse(response.body)['data']['attributes']['student']).to eq(student3.first_name)
        expect(JSON.parse(response.body)['data']['attributes']['status']).to eq("pending")
      end

      it "returns a not authorized error" do
        valid_params = {
          enrollment: {
            batch_id: batch.id,
            student_id: student3.id,
            status: "approved"
          }
        }
        expect {
          post "/api/v1/enrollments", headers: headers_4, params: valid_params, as: :json
        }.to_not change(Enrollment, :count)
        
        expect(response).to have_http_status(:forbidden)
        expect(response.body).to include("You are not authorized to perform this action.")
      end
    end
  end

  describe 'GET /api/v1/enrollments/:id' do
    let!(:student) { create(:user, :student) }
    let!(:enrollment) { create(:enrollment, :student) }

    context 'when the user is authenticated' do
      let(:user) { create(:user, :admin) }
      let(:headers) { sign_in(user) }

      it 'returns the enrollment details' do
        get "/api/v1/enrollments/#{enrollment.id}", headers: headers

        expect(response).to have_http_status(:ok)
        expect(JSON.parse(response.body)['data']['id']).to eq(enrollment.id.to_s)
      end
    end
  end

  describe 'PUT /api/v1/enrollments/:id/approve' do
    let(:admin) { create(:user, :admin) }
    let(:school_admin) { create(:user, :school_admin) }
    let(:student) { create(:user, :student) }
    let(:enrollment) { create(:enrollment, :student) }

    context 'when the user is an admin' do
      let(:headers) { sign_in(admin) }

      it 'approves the enrollment' do
        put "/api/v1/enrollments/#{enrollment.id}/approve", headers: headers

        expect(response).to have_http_status(:ok)
        expect(enrollment.reload.status).to eq('approved')
      end
    end

    context 'when the user is a school admin' do
      let(:headers) { sign_in(school_admin) }

      it 'approves the enrollment' do
        put "/api/v1/enrollments/#{enrollment.id}/approve", headers: headers

        expect(response).to have_http_status(:ok)
        expect(enrollment.reload.status).to eq('approved')
      end
    end

    context 'when the user is student then not authorized' do
      let(:headers) { sign_in(student) }

      it 'returns a forbidden status' do
        put "/api/v1/enrollments/#{enrollment.id}/approve", headers: headers

        expect(response).to have_http_status(:forbidden)
        expect(enrollment.reload.status).not_to eq('approved')
      end
    end
  end

  describe 'PUT /api/v1/enrollments/:id/deny' do
    let(:admin) { create(:user, :admin) }
    let(:school_admin) { create(:user, :school_admin) }
    let(:student) { create(:user, :student) }
    let(:enrollment) { create(:enrollment, :student) }
  
    context 'when the user is an admin' do
      let(:headers) { sign_in(admin) }
  
      it 'denies the enrollment' do
        put "/api/v1/enrollments/#{enrollment.id}/deny", headers: headers
  
        expect(response).to have_http_status(:ok)
        expect(enrollment.reload.status).to eq('denied')
      end
    end
  
    context 'when the user is a school admin' do
      let(:headers) { sign_in(school_admin) }
  
      it 'denies the enrollment' do
        put "/api/v1/enrollments/#{enrollment.id}/deny", headers: headers
  
        expect(response).to have_http_status(:ok)
        expect(enrollment.reload.status).to eq('denied')
      end
    end
  
    context 'when the user is a student' do
      let(:headers) { sign_in(student) }
  
      it 'returns a forbidden status' do
        put "/api/v1/enrollments/#{enrollment.id}/deny", headers: headers
  
        expect(response).to have_http_status(:forbidden)
        expect(enrollment.reload.status).not_to eq('denied')
      end
    end
  end
end
