require 'rails_helper'

RSpec.describe Enrollment, type: :model do
  describe 'associations' do
    it { should belong_to(:batch) }
    it { should belong_to(:student).class_name('User') }
  end

  describe 'validations' do
    let!(:existing_enrollment) { create(:enrollment, :student) }

    it { should validate_presence_of(:status) }
    it { should validate_uniqueness_of(:student_id).scoped_to(:batch_id).with_message('already enrolled in this batch') }
  end

  describe 'enums' do
    it { should define_enum_for(:status).with_values(pending: 0, approved: 1, denied: 2) }
  end

  describe 'scopes' do
    it 'should have an "approved" scope' do
      approved_enrollment = create(:enrollment, :student, status: :approved)
      pending_enrollment = create(:enrollment, :student, status: :pending)
      denied_enrollment = create(:enrollment, :student, status: :denied)

      expect(Enrollment.approved).to contain_exactly(approved_enrollment)
    end
  end
end
