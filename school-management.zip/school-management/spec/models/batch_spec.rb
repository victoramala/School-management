require 'rails_helper'

RSpec.describe Batch, type: :model do
  describe 'associations' do
    it { should belong_to(:course) }
    it { should have_many(:enrollments).dependent(:destroy) }
    it { should have_many(:students).through(:enrollments) }
  end
end
