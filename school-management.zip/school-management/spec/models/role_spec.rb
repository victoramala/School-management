require 'rails_helper'

RSpec.describe Role, type: :model do
  describe 'constants' do
    it 'defines USER_ROLES' do
      expect(Role::USER_ROLES).to eq(['Admin', 'SchoolAdmin', 'Student'])
    end
  end

  describe 'associations' do
    it { should have_many(:user_roles) }
    it { should have_many(:users).through(:user_roles) }
  end
end
