require 'rails_helper'

RSpec.describe Course, type: :model do
  describe 'associations' do
    it { should belong_to(:school) }
    it { should have_many(:batches).dependent(:destroy) }
    it { should have_many(:enrollments).through(:batches) }
  end

  describe 'nested attributes' do
    it { should accept_nested_attributes_for(:batches).allow_destroy(true) }
  end
end
