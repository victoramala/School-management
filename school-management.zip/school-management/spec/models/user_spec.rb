require 'rails_helper'

RSpec.describe User, type: :model do
  describe "validations" do
    it { should validate_presence_of(:first_name) }
    it { should validate_presence_of(:last_name) }
    it { should validate_presence_of(:email) }
    it { should validate_uniqueness_of(:email) }
    it { should allow_value("test@example.com").for(:email) }
    it { should_not allow_value("invalid_email").for(:email) }
    it { should validate_presence_of(:password) }
    it { should validate_length_of(:password).is_at_least(8) }
  end

  describe "associations" do
    it { should have_many(:user_roles) }
    it { should have_many(:roles).through(:user_roles) }
  end

  describe "methods" do
    let(:user) { create(:user) } # Assuming you have a factory for users

    it "returns the user's role" do
      expect(user.role).to eq(user.roles.first&.name)
    end

    it "checks if the user has a specific role" do
      expect(user.has_role?('Admin')).to be_falsey
      expect(user.has_role?('SchoolAdmin')).to be_falsey
      expect(user.has_role?('Student')).to be_falsey

      user.roles << Role.create(name: 'Admin')

      expect(user.has_role?('Admin')).to be_truthy
      expect(user.has_role?('SchoolAdmin')).to be_falsey
      expect(user.has_role?('Student')).to be_falsey
    end

    it "checks if the user is an admin" do
      expect(user.admin?).to be_falsey

      user.roles << Role.create(name: 'Admin')

      expect(user.admin?).to be_truthy
    end

    it "checks if the user is a school admin" do
      expect(user.school_admin?).to be_falsey

      user.roles << Role.create(name: 'SchoolAdmin')

      expect(user.school_admin?).to be_truthy
    end

    it "checks if the user is a student" do
      expect(user.student?).to be_falsey

      user.roles << Role.create(name: 'Student')

      expect(user.student?).to be_truthy
    end

    it "generates an authentication token" do
      auth_token = user.generate_auth_token

      expect(auth_token).not_to be_nil
      expect(JWT.decode(auth_token, Rails.application.secrets.secret_key_base)[0]['user_id']).to eq(user.id)
    end
  end
end
