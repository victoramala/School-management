module Helpers
  def sign_in(user)
    post '/sign_in', params: { user: { email: user.email, password: user.password } }, as: :json

    token = JSON.parse(response.body)['auth_token']

    {
      'Authorization' => "Bearer #{token}",
      'Content-Type' => 'application/json',
      'Accept' => 'application/json'
    }
  end

  def create_role(name)
    Role.create(name: name)
  end
end