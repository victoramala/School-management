require 'rails_helper'

RSpec.describe Api::V1::SchoolSerializer do
  let(:school) { create(:school) }
  let(:serializer) { described_class.new(school) }
  let(:serialization) { serializer.serializable_hash }

  it 'serializes the school object' do
    expect(serialization[:data][:id]).to eq(school.id.to_s)
    expect(serialization[:data][:type].to_s).to eq('school')
    expect(serialization[:data][:attributes][:name]).to eq(school.name)
    expect(serialization[:data][:attributes][:description]).to eq(school.description)
    expect(serialization[:data][:attributes][:address]).to eq(school.address)
    expect(serialization[:data][:attributes][:phone]).to eq(school.phone)
    expect(serialization[:data][:attributes][:created_by]).to eq(school.created_by)
  end

  it 'includes the associated courses' do
    expect(serialization[:data][:relationships][:courses][:data]).to eq(school.courses.map { |course| { id: course.id.to_s, type: 'course' } })
  end
end
