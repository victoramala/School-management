require 'rails_helper'

RSpec.describe Api::V1::EnrollmentSerializer do
  let(:batch) { create(:batch, name: 'Mathematics') }
  let(:student) { create(:user, first_name: 'Chante') }
  let(:enrollment) { create(:enrollment, batch: batch, student: student, status: 'pending') }

  subject { described_class.new(enrollment) }

  it 'serializes the enrollment' do
    expected_json = {
      data: {
        id: enrollment.id.to_s,
        type: :enrollment,
        attributes: {
          status: 'pending',
          student: 'Chante',
          batch: 'Mathematics'
        }
      }
    }

    expect(subject.serializable_hash).to eq(expected_json)
  end
end
