require 'rails_helper'

RSpec.describe Api::V1::CourseSerializer do
  let(:course) { create(:course) }
  let!(:batch1) { create(:batch, course: course) }
  let!(:batch2) { create(:batch, course: course) }

  describe 'serialization' do
    context 'when includes parameter includes batches' do
      let(:params) { { includes: 'batches' } }
      let(:serializer) { described_class.new(course, params: params) }
      let(:serialization) { serializer.serializable_hash }

      it 'serializes the course with included batches' do
        expect(serialization).to eq({
          data: {
            id: course.id.to_s,
            type: :course,
            attributes: {
              name: course.name,
              description: course.description,
              start_date: course.start_date,
              end_date: course.end_date,
              course_type: course.course_type,
              created_by: course.created_by
            },
            relationships: {
              batches: {
                data: [
                  {
                    id: batch1.id.to_s,
                    type: 'batch'
                  },
                  {
                    id: batch2.id.to_s,
                    type: 'batch'
                  }
                ]
              }
            }
          },
          included: [
            {
              id: batch1.id.to_s,
              type: 'batch',
              attributes: {
                name: batch1.name,
                description: nil,
                start_date: batch1.start_date,
                end_date: batch1.end_date,
                created_by: nil
              }
            },
            {
              id: batch2.id.to_s,
              type: 'batch',
              attributes: {
                name: batch2.name,
                description: nil,
                start_date: batch2.start_date,
                end_date: batch2.end_date,
                created_by: nil
              }
            }
          ]
        })
      end
    end

    context 'when includes parameter does not include batches' do
      let(:params) { {} }
      let(:serializer) { described_class.new(course, params: params) }
      let(:serialization) { serializer.serializable_hash }

      it 'serializes the course without included batches' do
        expect(serialization).to eq({
          data: {
            id: course.id.to_s,
            type: :course,
            attributes: {
              name: course.name,
              description: course.description,
              start_date: course.start_date.strftime('%Y-%m-%dT%H:%M:%S.%LZ'),
              end_date: course.end_date.strftime('%Y-%m-%dT%H:%M:%S.%LZ'),
              course_type: course.course_type,
              created_by: course.created_by
            }
          }
        })
      end
    end
  end
end
