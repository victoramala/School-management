require 'rails_helper'

RSpec.describe Api::V1::BatchSerializer do
  let(:batch) { create(:batch) } # Assuming you have a factory for batches

  subject { described_class.new(batch) }

  it "serializes the batch correctly" do
    serialization = subject.serializable_hash

    expect(serialization).to eq({
      data: {
        id: batch.id.to_s,
        type: :batch,
        attributes: {
          name: batch.name,
          description: batch.description,
          start_date: batch.start_date,
          end_date: batch.end_date,
          created_by: batch.created_by
        }
      }
    })
  end
end
