class EnrollmentPolicy < ApplicationPolicy
  def index?
    user.admin? || user.school_admin? || user.student?
  end

  def show?
    index?
  end

  def create?
    user.admin? || user.school_admin? || (user.student? && status_pending?)
  end

  def approve?
    user.admin? || user.school_admin?
  end

  def deny?
    approve?
  end

  private

  def status_pending?
    @record.status == 'pending'
  end
end