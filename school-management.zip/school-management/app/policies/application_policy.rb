# frozen_string_literal: true

class ApplicationPolicy
  attr_reader :user, :record

  def initialize(user, record)
    @user = user
    @record = record
  end

  def index?
    user.admin? || user.school_admin?
  end

  def show?
    user.admin? || user.school_admin?
  end

  def create?
    user.admin? || user.school_admin?
  end

  def new?
    user.admin? || user.school_admin?
  end

  def update?
    user.admin? || user.school_admin?
  end

  def edit?
    user.admin? || user.school_admin?
  end

  def destroy?
    user.admin? || user.school_admin?
  end

  class Scope
    def initialize(user, scope)
      @user = user
      @scope = scope
    end

    def resolve
      raise NotImplementedError, "You must define #resolve in #{self.class}"
    end

    private

    attr_reader :user, :scope
  end

  protected

  def admin?
    @user.admin?
  end

  def school_admin?
    @user.school_admin?
  end

  def student?
    @user.student?
  end
end
