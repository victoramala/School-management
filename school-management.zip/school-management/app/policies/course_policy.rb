class CoursePolicy < ApplicationPolicy
  def create?
    super
  end

  def update?
    super
  end

  def index?
    super
  end

  def show?
    super
  end
end