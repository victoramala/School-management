class SchoolPolicy < ApplicationPolicy
  def index?
    user.admin? || user.school_admin?
  end

  def create?
    user.admin?
  end

  def update?
    super
  end

  def show?
    super
  end

  def destroy?
    user.admin?
  end
end