class SchoolAdminPolicy < ApplicationPolicy
  def create_school_admin?
    user.admin?
  end
end
  