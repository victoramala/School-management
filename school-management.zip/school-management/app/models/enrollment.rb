class Enrollment < ApplicationRecord
  enum status: { pending: 0, approved: 1, denied: 2 }

  belongs_to :batch
  belongs_to :student, class_name: 'User'

  validates :status, presence: true
  validates :student_id, uniqueness: { scope: :batch_id, message: 'already enrolled in this batch' }

  scope :approved, -> { where(status: :approved) }
end
