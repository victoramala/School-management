class User < ApplicationRecord
  has_secure_password

  attribute :role

  # validations
  validates :first_name, :last_name, presence: true
  validates :email, presence: true, uniqueness: true, format: { with: URI::MailTo::EMAIL_REGEXP }
  validates :password, presence: true, length: { minimum: 8 }

  
  # associations
  has_many :user_roles
  has_many :roles, through: :user_roles

  def role
    roles.first&.name
  end

  def has_role?(role_name)
    roles.exists?(name: role_name)
  end

  def admin?
    has_role?('Admin')
  end

  def school_admin?
    has_role?('SchoolAdmin')
  end

  def student?
    has_role?('Student')
  end

  def generate_auth_token
    payload = { user_id: id }
    JWT.encode(payload, Rails.application.secrets.secret_key_base)
  end
end
  