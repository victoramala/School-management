class School < ApplicationRecord
  validates :name, presence: true
  has_many :courses, dependent: :destroy
  
  accepts_nested_attributes_for :courses, allow_destroy: true 
end
