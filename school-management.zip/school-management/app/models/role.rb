class Role < ApplicationRecord

  USER_ROLES = %w[
    Admin
    SchoolAdmin
    Student
  ].freeze

  has_many :user_roles
  has_many :users, through: :user_roles
end
