class Course < ApplicationRecord
  belongs_to :school
  has_many :batches, dependent: :destroy
  has_many :enrollments, through: :batches

  accepts_nested_attributes_for :batches,
  allow_destroy: true
end
