class SchoolAdmin < User
  has_many :schools
end
  