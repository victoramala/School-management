class SessionController < ApplicationController
  skip_before_action :verify_authenticity_token

  def sign_in
    @user = User.find_by(email: params[:user][:email])

    if @user && @user.authenticate(params[:user][:password])

      if request.format.html?
        session[:user_id] = @user.id
        redirect_to dashboard_path
      else
        render json: { auth_token: @user.generate_auth_token }, status: :created
      end
    else
      render json: { error: 'Invalid email or password' }, status: :unauthorized
    end
  end

  def logout
    session.delete(:user_id)
    redirect_to root_path
  end

  private

  def user_params
    params.require(:user).permit(:email, :password)
  end

  # def redirect_user(user)
  #   case user.role
  #   when "Admin"
  #     redirect_to admin_dashboard_path
  #   when "SchoolAdmin"
  #     redirect_to school_admin_dashboard_path
  #   when "Student"
  #     redirect_to student_dashboard_path
  #   else
  #     flash[:error] = "Invalid role"
  #     render :new
  #   end
  # end
end
