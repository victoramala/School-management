class ApplicationController < ActionController::Base
  include Pundit::Authorization
  protect_from_forgery unless: -> { request.format.json? }
  before_action :authenticate_token!, except: [:logout, :sign_in, :login]
  helper_method :current_user
  
  private

  def authenticate_token!
    if request.format.html?
      redirect_to home_login_path unless session[:user_id]
    else
      auth_header = request.headers['Authorization']
      token = auth_header.split(' ')[1] if auth_header
      begin
        payload = JWT.decode(token, Rails.application.secrets.secret_key_base, true, algorithm: 'HS256')
        @current_user = User.find(payload[0]['user_id'])
      rescue JWT::ExpiredSignature
        render json: { error: 'Token has expired' }, status: :unauthorized
      rescue JWT::DecodeError
        render json: { error: 'Token is invalid' }, status: :unauthorized
      end
    end
  end

  def current_user
    @current_user ||= User.find_by(id: session[:user_id])
  end

  def html_request?
    request.format.html?
  end
end
