class DashboardController < ApplicationController
  before_action :authenticate_token!

  def index
    @schools = School.all
    @courses = Course.all
    @batches = Batch.all
  end
end
