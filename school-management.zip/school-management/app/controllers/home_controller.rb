class HomeController < ApplicationController
  skip_before_action :authenticate_token!

  def index
  end

  def login
  end
end
 