module UserCreator
  extend ActiveSupport::Concern

  def create_user_with_role(role, user_params)
    user = User.new(user_params)

    if user.valid?
      if !role.nil?
        user.user_roles.build(role: role)
        if user.save
          user
        else
          raise StandardError, "Failed to create user"
        end
      else
        raise StandardError, "Unsupported Role: Must be one of #{Role::USER_ROLES.join(', ')}"
      end
    else
      raise StandardError, user.errors.full_messages.join(", ")
    end
  end

  def authenticate_user(user_params, redirect_url = nil)
    user = User.new(user_params)

    if user.valid?
      if !role.nil?
        user.user_roles.build(role: role)
        if user.save
          user
        else
          raise StandardError, "Failed to create user"
        end
      else
        raise StandardError, "Unsupported Role: Must be one of #{Role::USER_ROLES.join(', ')}"
      end
    else
      raise StandardError, user.errors.full_messages.join(", ")
    end
  end
end
    