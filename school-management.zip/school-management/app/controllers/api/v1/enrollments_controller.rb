class Api::V1::EnrollmentsController < Api::V1::BaseController
  before_action :set_enrollment, only: [:show, :approve, :deny]

  def create
    enrollment = Enrollment.new(enrollment_params)
    authorize enrollment
    if enrollment.save
      render json: Api::V1::EnrollmentSerializer.new(enrollment), status: :created
    else
      render json: { errors: enrollment.errors.full_messages }, status: :unprocessable_entity
    end
  end

  def show
    authorize @enrollment
    render json: Api::V1::EnrollmentSerializer.new(@enrollment), status: :ok
  end

  def approve
    authorize @enrollment
    if @enrollment.approved!
      render json: Api::V1::EnrollmentSerializer.new(@enrollment), status: :ok
    else
      render json: { errors: @enrollment.errors.full_messages }, status: :unprocessable_entity
    end
  end

  def deny
    authorize @enrollment
    if @enrollment.denied!
      render json: Api::V1::EnrollmentSerializer.new(@enrollment), status: :ok
    else
      render json: { errors: @enrollment.errors.full_messages }, status: :unprocessable_entity
    end
  end

  private

  def set_enrollment
    @enrollment = Enrollment.find(params[:id])
  end

  def enrollment_params
    params.require(:enrollment).permit(:batch_id, :student_id, :status)
  end
end
  