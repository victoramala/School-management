class Api::V1::Schools::CoursesController < Api::V1::BaseController
    before_action :set_school
    before_action :set_course, only: [:show, :update, :destroy]
  
    def index
      authorize Course

      @courses = @school.courses.includes(:batches).page(params[:page]).per(params[:per_page])
      options = {}
      options[:meta] = pagination_dict(@courses)
      options[:params] = { includes: 'batches' } if params[:includes].present? && params[:includes] == "batches"
      render json: Api::V1::CourseSerializer.new(@courses, options).serialized_json
    end
  
    def show
      authorize @course
      options = {}
      options[:include] = [:batches] if params[:includes] == "batches" || params[:include] == "batches" if params[:includes] == "batches" || params[:include] == "batches" 
      render json: Api::V1::CourseSerializer.new(@course, options).serialized_json
    end
  
    def create
      authorize Course

      @course = @school.courses.build(course_params)
      if @course.save
        render json: Api::V1::CourseSerializer.new(@course).serialized_json, status: :created
      else
        render json: @course.errors, status: :unprocessable_entity
      end
    end
  
    def update
      authorize @course

      if @course.update(course_params)
        render json: Api::V1::CourseSerializer.new(@course).serialized_json
      else
        render json: @course.errors, status: :unprocessable_entity
      end
    end
  
    def destroy
      authorize @course

      @course.destroy
      render json: { message: "Course has been successfully deleted." }, status: :ok
    end
  
    private
  
    def set_school
      @school = School.find(params[:school_id])
    end
  
    def set_course
      @course = @school.courses.find(params[:id])
    end
  
    def course_params
      params.require(:course).permit(:name, :description, :start_date, :end_date, :course_type, :created_by, batches_attributes: [:id, :name, :start_date, :end_date, :description, :created_by, :_destroy])
    end
  end
  