class Api::V1::Batches::EnrollmentsController < Api::V1::BaseController
  before_action :set_batch, only: [:index]

  def index
    authorize Enrollment
    enrollments = @batch.enrollments.includes(:student, :batch).page(params[:page]).per(params[:per_page])
    options = {}
    options[:meta] = pagination_dict(enrollments)
    render json: Api::V1::EnrollmentSerializer.new(enrollments, options).serialized_json
  end

  private

  def set_batch
    @batch = Batch.find(params[:batch_id])
  end
end
  