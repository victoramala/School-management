class Api::V1::SchoolsController < Api::V1::BaseController
    before_action :set_school, only: [:show, :update, :destroy]
  
    def index
      authorize School
      @schools = School.all.page(params[:page]).per(params[:per_page])
      options = {}
      options[:meta] = pagination_dict(@schools)
      render json: Api::V1::SchoolSerializer.new(@schools, options).serialized_json
    end
  
    def show
      authorize @school
      render json: Api::V1::SchoolSerializer.new(@school).serialized_json
    end
  
    def create
      authorize School

      @school = School.new(school_params)
      if @school.save
        render json: Api::V1::SchoolSerializer.new(@school).serialized_json, status: :created
      else
        render json: @school.errors, status: :unprocessable_entity
      end
    end
  
    def update
      authorize @school

      if @school.update(school_params)
        render json: Api::V1::SchoolSerializer.new(@school).serialized_json
      else
        render json: @school.errors, status: :unprocessable_entity
      end
    end
  
    def destroy
      authorize @school
      @school.destroy
      render json: { message: "School has been successfully deleted." }, status: :ok
    end
  
    private
  
    def set_school
      @school = School.find(params[:id])
    end
  
    def school_params
      params.require(:school).permit(:name, :description, :address, :phone, :created_by)
    end
  end
  