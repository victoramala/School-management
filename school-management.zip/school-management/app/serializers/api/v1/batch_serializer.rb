module Api
  module V1
    class BatchSerializer < BaseSerializer
      attributes :name, :description, :start_date, :end_date, :created_by
    end
  end
end
  