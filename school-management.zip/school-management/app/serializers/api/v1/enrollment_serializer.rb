module Api
  module V1
    class EnrollmentSerializer < BaseSerializer
      attributes :status

      attribute :student do |record|
        record&.student&.first_name
      end

      attribute :batch do |record|
        record&.batch&.name
      end
    end
  end
end
    