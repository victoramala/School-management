module Api
    module V1
      class SchoolSerializer < BaseSerializer
        attributes :name, :description, :address, :phone, :created_by

        has_many :courses
      end
    end
  end
  