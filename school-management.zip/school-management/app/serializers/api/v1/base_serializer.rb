module Api
    module V1
      class BaseSerializer
        include FastJsonapi::ObjectSerializer

        def self.conditional_include(association)
          attribute association do |record, params|
            record.send(association) if params[:includes].present? && params[:includes].include?(association.to_s)
          end
        end
      end
    end
  end
  