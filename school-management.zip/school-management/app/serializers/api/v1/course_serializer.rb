module Api
    module V1
      class CourseSerializer < BaseSerializer
        attributes :name, :description, :start_date, :end_date, :course_type, :created_by

        has_many :batches, if: Proc.new { |record, params| params[:includes].present? && params[:includes].include?('batches') }

        conditional_include :batches
      end
    end
  end
  