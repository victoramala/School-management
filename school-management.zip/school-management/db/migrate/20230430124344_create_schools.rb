class CreateSchools < ActiveRecord::Migration[7.0]
  def change
    create_table :schools do |t|
      t.string :name
      t.text :description
      t.text :address
      t.string :phone
      t.integer :created_by

      t.timestamps
    end
  end
end
